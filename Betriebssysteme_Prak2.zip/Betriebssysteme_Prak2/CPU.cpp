/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   CPU.cpp
 * Author: Joel
 * 
 * Created on 19. November 2019, 18:18
 */

#include "CPU.h"

CPU::CPU() {
    isRunning = true;
    R1 = 0;
    P_COUNTER = 0;
    STARTTIME = time(0);
    
    Prozess init("init.txt");
}

int CPU::getRUNTIME()
{
    RUNTIME = time(0)-STARTTIME;
    
    return RUNTIME;
}

void CPU::printCurrentStatus()
{
    cout <<     "***************\n" <<
                "The current system state is as follows:\n" <<
                "***************\n" <<
                "CURRENT TIME: " << getRUNTIME() << endl;
                printRunning();
                printblocked();
                printunblocked();
    cout <<     "***************\n";
}

void CPU::printblocked()
{
    cout << "BLOCKED PROCESS:" << endl;
}

void CPU::printunblocked()
{
    cout << "PROCESSES READY TO EXECUTE:" << endl;

}

void CPU::printRunning()
{
    cout << "RUNNING PROCESS:" << endl;

}