/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Prozess.cpp
 * Author: Joel
 * 
 * Created on 19. November 2019, 18:18
 */

#include "Prozess.h"
#include "CPU.h"

int Prozess::pidseed = 0;

Prozess::Prozess(string filename) {
    readFromFile(filename);
    this->STARTTIME = time(0);
    PID = pidseed;
    pidseed++;
    cout << PID;
    runProgram();
}

void Prozess::readFromFile(string filename)
{
    ifstream input;
    string path = "C:/Users/Joel/Documents/NetBeansProjects/Betriebssysteme_Prak2/";
    path += filename;
    input.open(path);
    if (!input) 
    {
    cerr << "Unable to open file!";
    }
    
    string line;
    while (getline(input, line)) 
    {      
        string cur = line;
        PROGRAM.push_back(cur);
    }
}

int Prozess::getRUNTIME()
{
    RUNTIME = time(0) - this->STARTTIME;
    return RUNTIME;
}

void Prozess::runProgram()
{
    for (int i = 0; i < PROGRAM.size(); i++) {
        string cur = PROGRAM[i];
        
        string cmd = this->extractCmd2(cur);
        string arg = this->extractArg2(cur);
        
        //DEFINE
        if(cmd == "D")
        {
            VALUE = stoi(arg);   
        }
        //ADD
        if(cmd == "A")
        {
            VALUE += stoi(arg);
        }
        //SUBTRACT
        if(cmd == "S")
        {
            VALUE -= stoi(arg);
        }
        //BLOCK
        if(cmd == "B")
        {
            //TODO
        }
        //EXIT
        if(cmd == "X")
        {
            //TODO
        }
        //RUN
        if(cmd == "R")
        {
            //TODO
        }
    }

}

string extractCmd2(string input)
{
    string cmd = input;
    for (int i = 0; i < input.length(); i++) 
    {
        if(input.at(i) == ' ')
        {
            cmd = input.substr(0,i);
            break;
        }
    }    
    return cmd;
}

string extractArg2(string input)
{
    string arg = "";
    for (int i = 0; i < input.length(); i++) 
    {
        if(input.at(i) == ' ')
        {
            if(input.length() > i)
            arg = input.substr(i+1);
            break;
        }
    }
    return arg;
}