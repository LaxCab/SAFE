/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Joel
 *
 * Created on 19. November 2019, 18:14
 */

#include <cstdlib>
#include <iostream>
#include <valarray>

#include "Prozess.h"
#include "CPU.h"

using namespace std;

//GLOBALS
CPU myCPU;



//HELPER-Funktionen
string extractCmd(string input)
{
    string cmd = input;
    for (int i = 0; i < input.length(); i++) 
    {
        if(input.at(i) == ' ')
        {
            cmd = input.substr(0,i);
            break;
        }
    }    
    return cmd;
}

string extractArg(string input)
{
    string arg = "";
    for (int i = 0; i < input.length(); i++) 
    {
        if(input.at(i) == ' ')
        {
            if(input.length() > i)
            arg = input.substr(i+1);
            break;
        }
    }
    return arg;
}

//Benutzer<->Simulation Schnittstelle
void step(string arg)
{
    if(arg=="")
        {
            arg = "1";
        }
}

void unblock()
{
    
}

void print()
{
    myCPU.printCurrentStatus();
}

void quit()
{
    //TODO: Ausgabe der durschnittlichen simulierten Durchlaufzeit 
    //(Takte per Prozess) und Beendigung des Systems
    myCPU.isRunning = false;
}

void userInput()
{
    //MENÜ
    cout << "___________________________" << endl
         << "# >";
    char input[30];
    cin.getline(input,30);
    
    extractCmd(input);
    string cmd = extractCmd(input);
    string arg = extractArg(input);
    
       //STEP-Command
    if((cmd == "S") || (cmd == "Step") || (cmd == "s"))
    {
        cout << "Step" << endl;
        step(arg);
    }else
    // UNBLOCK-Command
    if((cmd == "U") || (cmd == "Unblock") || (cmd == "u"))
    {
        cout << "Unblock" << endl;
        unblock();
    }
    else
    // PRINT-Command
    if((cmd == "P") || (cmd == "Print") || (cmd == "p"))
    {
        cout << "Print" << endl;
        print();
    }else
    // QUIT-Command
    if((cmd == "Q") || (cmd == "Quit") || (cmd == "q"))
    {
        cout << "Quit" << endl;
        quit();
    }
    // Kommando unbekannt
    else cout << "Kommando unbekannt!" << endl;
}


/*
 * 
 */
int main() {

    while(myCPU.isRunning)
    {
        userInput();
    }
    
    return 0;
}

