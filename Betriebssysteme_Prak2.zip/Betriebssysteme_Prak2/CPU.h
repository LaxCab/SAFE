/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   CPU.h
 * Author: Joel
 *
 * Created on 19. November 2019, 18:18
 */

#ifndef CPU_H
#define CPU_H

#include "Prozess.h"
#include <vector>
#include <time.h>
#include <iostream>
#include <string>
#include <fstream>

class Prozess;

using namespace std;

class CPU {
public:
    CPU();
        
    //CPU-STATUS
    bool isRunning;
    
    //Prozessverwaltung
    Prozess active(); //Aktiver Prozess
    vector<Prozess> unblocked;
    vector<Prozess> blocked;
    
    void saveProcess(Prozess toSave);
    void blockProcess(Prozess toBlock);
    void startProcess(Prozess toStart);
    void restoreProcess(Prozess toRestore);
    
    //CPU-ATTRIBUTE
    int R1;
    int P_COUNTER;
    time_t STARTTIME;
    int RUNTIME;
    
    //GETTER
    int getRUNTIME();
    void printCurrentStatus();
    void printRunning();
    void printblocked();
    void printunblocked();
    
private:

};

#endif /* CPU_H */

