/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Prozess.h
 * Author: Joel
 *
 * Created on 19. November 2019, 18:18
 */

#ifndef PROZESS_H
#define PROZESS_H

#include "CPU.h"  
using namespace std;

class Prozess : public CPU{
public:
    Prozess(string filename);
    
    static int pidseed;
        
    //ATTRIBUTE
    int PID;
    int PPID;
    int PRIORITY;
    int VALUE;
    time_t STARTTIME;
    int RUNTIME;
    
    //Befehlsspeicher
    vector<string> PROGRAM;
    
    //Programm ausführen
    void runProgram();
    void readFromFile(string filename);
    int getRUNTIME();
    
    
    //HELPER
    string extractCmd2(string input);
    string extractArg2(string input);
    
    
private:

};

#endif /* PROZESS_H */

