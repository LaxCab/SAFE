/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   CPU.cpp
 * Author: laxcab
 * 
 * Created on 17. November 2019, 19:52
 */

#include "CPU.h"

CPU::CPU() {
    this->reset();
    this->start();
}

void CPU::reset()
{
    //RESET CLOCK
    this->STARTTIME = getCurrentTime();
    R1 = 0;
    R2 = 0;
}

void CPU::start()
{
    simulationRunning = true;
    cout << "CPU gestartet" << endl;
    this->runProcess("init.txt");
}

time_t CPU::getCurrentTime()
{
    time_t curtime = time(0);
    string now = ctime(&curtime);
    return curtime;
}

void CPU::runProcess(string file)
{
    ifstream input;
    string path = "/home/laxcab/All/NetBeansProjects/SAFE-master/";
    path += file;
    input.open(path);
    
    if (!input) {
    cerr << "Unable to open file!";
}
    string line;
    while (getline(input, line)) {      
        string cur = line;
        string cmd = commandCutter(cur);
        string arg = argumentCutter(cur);
        
        //DEFINE
        if(cmd == "D")
        {
            R1 = stoi(arg);   
        }
        //ADD
        if(cmd == "A")
        {
            R1 += stoi(arg);
        }
        //SUBTRACT
        if(cmd == "S")
        {
            R1 -= stoi(arg);
        }
        //BLOCK
        if(cmd == "B")
        {
            //TODO
        }
        //EXIT
        if(cmd == "X")
        {
            //TODO
        }
        //RUN
        if(cmd == "R")
        {
            //TODO
        }
}
    
    
}

string CPU::commandCutter(string input)
{
    string cmd = input;
    for (int i = 0; i < input.length(); i++) 
    {
        if(input.at(i) == ' ')
        {
            cmd = input.substr(0,i);
            break;
        }
    }    
    
    return cmd;
}

string CPU::argumentCutter(string input)
{
    string arg = "";
    for (int i = 0; i < input.length(); i++) 
    {
        if(input.at(i) == ' ')
        {
            if(input.length() > i)
            arg = input.substr(i+1);
            break;
        }
    }
    
    return arg;
}

void CPU::printStatus()
{
    cout << "****************************" << endl
         << "The current system state is as follows:" << endl
         << "****************************" << endl
         << "CURRENT TIME: " << getCurrentTime()-STARTTIME << endl
         << "****************************" << endl;
}